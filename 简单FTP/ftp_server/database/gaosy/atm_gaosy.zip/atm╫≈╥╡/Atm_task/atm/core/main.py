#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from core import logger
from core.auth import login_required
from core import accounts
from core import transaction
from core import auth
import sys
#transaction logger
trans_logger = logger.logger("transaction")
# access logger
access_logger = logger.logger("access")

#temp account data ,only saves the data in memory
user_data = {
    'account_id':None,
    'is_authenticated':False,
    'account_data':None
}

def account_info(acc_data):
    data = {
        0: 'normal',
        1: 'locked',
        2: 'disabled'
    }
    a_data = acc_data['account_data']
    info = '''----------account information-------------------
    信用卡额度：%f
    可用额度： %f
    注册时间： %s
    过期时间: %s
    剩余天: %d
    信用卡状态：%s
---------------------------------------'''%(a_data['credit'],a_data['balance'],a_data['enroll_date'],a_data['expire_date'],a_data['pay_day'],data[a_data['status']])
    print(info)

def interactive(acc_data):
    '''
    interact with user
    :return:
    '''
    menu = u'''
    ------- Oldboy Bank ---------
    \033[32;1m1.  账户信息
    2.  还款
    3.  取款
    4.  转账
    5.  账单
    6.  退出
    \033[0m'''
    menu_dic = {
        '1': account_info,
        '2': repay,
        '3': withdraw,
        '4': transfer,
        '5': pay_check,
        '6': logout,
    }
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>:").strip()
        if user_option in menu_dic:
            # print('accdata',acc_data)
            #acc_data['is_authenticated'] = False
            menu_dic[user_option](acc_data)

        else:
            print("\033[31;1mOption does not exist!\033[0m")


def logout(acc_data):
    sys.exit(1)

def pay_check(acc_data):
    month = input("请输入月份，按照05的格式>>>")
    data = accounts.load_buy_log(acc_data['account_id'])
    print(data)
    if not data:
        print("{}该用户没有消费记录".format(acc_data['account_id']))


    print("\033[32;1m")
    for index in data:
        print("="*50)
        if month == index:
            print("{}月的消费记录".format(index))
            for comm in data[index]:
                print(comm)
        else:
            print("{}月没有消费记录".format(month))

    print("\033[0m")


@login_required
def repay(acc_data):
    '''
    print current balance and let user repay the bill
    :return:
    '''
    account_data = accounts.load_current_balance(acc_data['account_id'])
    #for k,v in account_data.items():
    #    print(k,v )
    current_balance= ''' --------- BALANCE INFO --------
        Credit :    %s
        Balance:    %s''' %(account_data['credit'],account_data['balance'])
    print(current_balance)
    back_flag = False
    while not back_flag:
        repay_amount = input("\033[33;1mInput repay amount:\033[0m").strip()
        if len(repay_amount) >0 and repay_amount.isdigit():
            print('ddd 00')
            new_balance = transaction.make_transaction(trans_logger,account_data,'repay', repay_amount)
            if new_balance:
                print('''\033[42;1mNew Balance:%s\033[0m''' %(new_balance['balance']))

        else:
            print('\033[31;1m[%s] is not a valid amount, only accept integer!\033[0m' % repay_amount)

        if repay_amount == 'b':
            back_flag = True

def run():
    '''
        this function will be called right a way when the program started, here handles the user interaction stuff
        :return:
        '''
    acc_data = auth.acc_login(user_data, access_logger)
    if user_data['is_authenticated']:
        user_data['account_data'] = acc_data
        interactive(user_data)

def transfer(acc_data):
    account_data = accounts.load_current_balance(acc_data['account_id'])
    tran_id = input("请输入转账账户>>")
    tran_data = accounts.load_current_balance(tran_id)

    current_balance = account_data['balance']
    tran_balance = tran_data['balance']

    if not tran_data:
        trans_logger.error("转账账户{tran_id}不存在".format(tran_id=tran_id))
        return
    while True:
        tran_amount = input("请输入转账金额>>").strip()
        if not tran_amount.isdigit():
            print("\033[1;31;1m 请输入数字\033[0m")
            continue
        tran_amount_int = int(tran_amount)
        if tran_amount_int > current_balance:
            print("余额不足，当前的余额是：{balance}元".format(balance=current_balance))
            continue

        new_currunt_balance = current_balance - tran_amount_int
        account_data['balance'] = new_currunt_balance
        new_tran_balance = tran_balance + tran_amount_int
        tran_data['balance'] = new_tran_balance

        accounts.dump_account(account_data)
        accounts.dump_account(tran_data)

        trans_logger.info("{} 向 {} 转账 {}元成功".format(acc_data['account_id'], tran_id, tran_amount))

        break
    return True















def withdraw(acc_data):
    '''
        print current balance and let user do the withdraw action
        :param acc_data:
        :return:
        '''
    account_data = accounts.load_current_balance(acc_data['account_id'])
    current_balance = ''' --------- BALANCE INFO --------
            Credit :    %s
            Balance:    %s''' % (account_data['credit'], account_data['balance'])
    print(current_balance)
    back_flag = False
    while not back_flag:
        withdraw_amount = input("\033[33;1mInput withdraw amount:\033[0m").strip()
        if len(withdraw_amount) > 0 and withdraw_amount.isdigit():
            new_balance = transaction.make_transaction(trans_logger, account_data, 'withdraw', withdraw_amount)
            if new_balance:
                print('''\033[42;1mNew Balance:%s\033[0m''' % (new_balance['balance']))

        else:
            print('\033[31;1m[%s] is not a valid amount, only accept integer!\033[0m' % withdraw_amount)

        if withdraw_amount == 'b':
            back_flag = True


