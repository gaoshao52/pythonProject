#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os,sys
atm_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
root_dir = os.path.dirname(atm_dir)
sys.path.append(root_dir)
sys.path.append(atm_dir)
from core import db_handler
import json

def load_current_balance(account_id):
    db_api = db_handler.db_handler()
    data = db_api("select * from accounts where account=%s" % account_id)
    return data

def dump_account(account_data):
    db_api = db_handler.db_handler()
    data = db_api("update accounts where account=%s" % account_data['id'], account_data=account_data)
    return True

def add_account(account_data):
    db_api = db_handler.db_handler()
    sql = "insert into accounts(id,password,credit,balance,enroll_date,expire_date,pay_day,status)" + \
          " values({id},{password},{credit},{balance},{enroll_date},{expire_date},{pay_day},{status})".format(
              id = account_data['id'],
              password = account_data['password'],
              credit = account_data['credit'],
              balance = account_data['balance'],
              enroll_date = account_data['enroll_date'],
              expire_date = account_data['expire_date'],
              pay_day = account_data['pay_day'],
              status = account_data['status']
          )

    data = db_api("select * from accounts where account=%s" % account_data['id'])
    if not data:

        return db_api(sql)
    else:
        print("account id {} has exists".format(account_data['id']))
        return False

def load_buy_log(account_id):
    buy_log_path = "%s/db/buy_list/%s.json"%(atm_dir, account_id)
    if os.path.isfile(buy_log_path):
        with open(buy_log_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    else:
        print("buy log does not exits")
        return

def dump_buy_log(account_id, data):
    buy_log_path = "%s/db/buy_list/%d.json"%(atm_dir, account_id)
    # print(buy_log_path)
    with open(buy_log_path, "w", encoding="utf-8") as f:
        json.dump(data, f)
    return True

