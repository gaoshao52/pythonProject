#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from core import logger
from core import accounts
import time
# manage log
manage_log = logger.logger('manage')


def add_user_data():
    print('\033[1;31;47m')
    print("*"*50)
    print("*ID:\t","(请输入账户id，要求数字)")
    id = input(">>").strip()

    print("*PASSWORD:\t", "(请输入账户密码)")
    password = input(">>").strip()
    print("*CREDIT:\t", "(请输入账户信用额度)")
    credit = input(">>").strip()
    print("*BALANCE:\t", "(请输入账户可用额度)")
    balance = input(">>").strip()
    enroll_date = time.strftime("%Y-%m-%d")
    print("*EXPIRE_DATE:\t", "(请输入账户有效截止日,按照2016-05-12格式)")
    expire_date = input(">>").strip()
    pay_day = 0
    status = 0
    print("*" * 50)
    print('\033[0m')

    account_data ={}
    account_data['id'] = id

    account_data['password'] = password
    account_data['credit'] = credit
    account_data['balance'] = balance
    account_data['enroll_date'] = enroll_date
    account_data['expire_date'] = expire_date
    account_data['pay_day'] = pay_day
    account_data['status'] = status

    return account_data

def add_user_data_to_db():
    if accounts.add_account(add_user_data()):
        manage_log.info("add new user success")
        return True
    else:
        manage_log.error("add new user failed")

def add_user_credit():
    while True:
        account_id = input("\033[32;1mpls input account_id:\033[0m")
        if not account_id.isdigit():
            manage_log.error("input account_id format error")
            continue
        account_id = int(account_id)
        break

    while True:
        amount = input("\033[32;1mpls input amount:\033[0m")
        if not amount.isdigit():
            manage_log.error("input amount format error")
            continue
        amount = int(amount)
        break


    data = accounts.load_current_balance(account_id)
    if not data:
        manage_log.error("[account_id] does not exist")
        return False
    old_credit = data['credit']
    if old_credit < amount:
        data['credit'] = amount
        accounts.dump_account(data)
        manage_log.info("update {account_id} credit success ".format(account_id=account_id))
        return True
    else:
        manage_log.warning("you shall a bigger credit amount")
        return False

def frozen_account():
    while True:
        account_id = input("\033[32;1mpls input account_id:\033[0m")
        if not account_id.isdigit():
            manage_log.error("input account_id format error")
            continue
        break
    data = accounts.load_current_balance(account_id)
    if not data:
        manage_log.error("[account_id] does not exist")
        return False
    data['status'] = 1
    accounts.dump_account(data)
    manage_log.info("frozen {account_id} success ".format(account_id=account_id))
    return True

def interactive():
    menu = u'''
        ------- Oldboy Bank ---------
        \033[32;1m1.  添加用户
        2.  增加用户额度
        3.  冻结用户
        \033[0m'''

    menu_dic = {
        '1': add_user_data_to_db,
        '2': add_user_credit,
        '3': frozen_account,
    }

    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>:").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()

        else:
            manage_log.warning("option id [%s] does not in the list"% user_option)


def run():
    interactive()


if __name__ == "__main__":
    run()