#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import json

mall_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))



def load_shop_data():
    shop_path = "%s/shop_db/shop/xiaomi.json"% mall_dir
    with open(shop_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data

