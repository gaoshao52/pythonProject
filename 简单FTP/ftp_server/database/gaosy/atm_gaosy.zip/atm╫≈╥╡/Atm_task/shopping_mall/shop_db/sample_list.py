#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import json

commoditys_list = {
    "1": ["小米5X", 1499],
    "2": ["小米MIX 2", 3999],
    "3": ["小米MAX 2", 1999],
    "4": ["小米笔记本Pro", 6999],
    "5": ["小米电视4A", 5499]
}

mall_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

xiaomi_shop = "%s/db/shop/xiaomi.json"%mall_dir

with open(xiaomi_shop, "r", encoding="utf-8") as f:
    data = json.load(f)

print(data)