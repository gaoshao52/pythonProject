#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import sys,os
mall_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
root_dir = os.path.dirname(mall_dir)
sys.path.append(root_dir)
sys.path.append(mall_dir)
from shop_core import shops
from atm.core import accounts
import time




shopping_cart = []

user_info = {
    'username': "sam",
    'pass': "123456"
}

def print_shopping_cart(data):

    print("\033[32;1m")
    print("购物车有以下商品>>")
    for index in data:
        print("{} : {}元".format(index[0], index[1]))
    print("\033[0m")


def print_shop_info():
    commdity_data = shops.load_shop_data()

    print("\033[36;1m")
    for index in commdity_data:
        print("%s: %s, %d 元"%(index, commdity_data[index][0], commdity_data[index][1]))

    print("\033[0m")

def login():
    print("\033[31;1m欢迎来到小米之家\033[0m")
    while True:
        user = input("请输入id：")
        password = input("请输入密码：")

        if user == user_info['username'] and password == user_info['pass']:
            print("\033[32;1m%s登陆成功\033[0m" % user)
            break
        else:
            print("\033[31;1m用户名或密码错误\033[0m")
            continue

def buy():
    commdity_data = shops.load_shop_data()
    while True:
        print_shop_info()
        user_choice = input("想要购物吗？输入商品编号，购物；输入q，信用卡结账；输入h，查询购物车；exit，退出购物>>>>>")
        if user_choice in commdity_data:
            shopping_cart.append(commdity_data[user_choice])
        elif user_choice == "h":
            print_shopping_cart(shopping_cart)
        elif user_choice == "q":
            total_money = 0
            log_to_db = {}
            for index in shopping_cart:
                total_money += index[1]
                log_to_db['index[0]'] = index[1]
            while True:
                account_id = input("请输入你的ID：").strip()
                user_data = accounts.load_current_balance(account_id)
                if not user_data:
                    print("{}用户不存在".format(account_id))
                    continue
                break
            while True:
                passwd = input("请输入密码：")
                if passwd == user_data['password']:
                    month = time.strftime("%m")
                    user_money = user_data['balance']
                    if user_money < total_money:
                        print("您的余额不足，当前的余额为{}".format(user_money))
                        break
                    else:
                        new_money = user_money - total_money
                        user_data['balance'] = new_money
                        accounts.dump_account(user_data)
                        print("付款成功，您当前的余额为{}".format(new_money))

                        old_buy_data = accounts.load_buy_log(user_data['id'])
                        # old_buy_data = {}
                        # if not old_buy_data:
                        #     old_buy_data = {}
                        #     old_buy_data[month] = [shopping_cart]

                        if not old_buy_data:
                            old_buy_data = {}
                            old_buy_data[month] = [shopping_cart]
                        elif month in old_buy_data:
                            old_buy_data[month].append(shopping_cart)
                        else:
                            old_buy_data[month] = [shopping_cart]
                        # print(user_data['id'])
                        # print(old_buy_data)
                        accounts.dump_buy_log(user_data['id'], old_buy_data)

                        break

        elif user_choice == "exit":
            logout()
        else:
            print("请输入正确的选项")






def logout():
    print("谢谢下次光临")
    sys.exit(1)

def run():

    login()
    buy()

if __name__ == '__main__':
    run()




